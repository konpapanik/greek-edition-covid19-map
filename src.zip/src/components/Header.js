import React, { useState } from 'react';
import { Link } from "gatsby"
import 'assets/stylesheets/components/__components.scss';
import { Button } from 'reactstrap';

import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavbarText
} from 'reactstrap';


//class Header extends React.component

 const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const toggle = () => setIsOpen(!isOpen);
  return (
    <div>
      <Navbar fixed="top" color="dark" dark expand="lg">
        <NavbarBrand><Link to="/">Ελλάδα | VirusNearBy</Link></NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="container" navbar>
            <NavItem>
            <Link to="/geolocate/">Fly Home</Link>
            </NavItem>
            <NavItem>
            <Link to="/europe/">Ευρώπη</Link>
            </NavItem>
            <NavItem>
            <Link to="/northamerica/">Β.Αμερική</Link>
            </NavItem>
            <NavItem>
            <Link to="/southamerica/">Ν.Αμερική</Link>
            </NavItem>
            <NavItem>
            <Link to="/africa/">Αφρική</Link>
            </NavItem>
            <NavItem>
            <Link to="/asia/">Ασία</Link>
            </NavItem>
            <NavItem>
            <Link to="/australia/">Αυστραλία</Link>
            </NavItem>
            <NavItem>
            <a style={{ color: 'greenyellow' }} href="https://virusnearby.com">Κάρτες Περιοχών</a>
            </NavItem>
          </Nav>
          <NavbarText><Button color="success" border-radius= "20" href="https://virusnearby.com/data-sources/" target="_blank">info</Button>{''}</NavbarText>
        </Collapse>
      </Navbar>
    </div>
  );
 }

 export default Header;
